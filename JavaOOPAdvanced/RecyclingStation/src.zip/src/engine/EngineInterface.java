package engine;

import java.io.IOException;

/**
 * Created by stefanangelov on 8/7/16.
 */
public interface EngineInterface {
    public void run() throws IOException;

}
