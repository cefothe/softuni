package io.writer;

/**
 * Created by stefanangelov on 8/7/16.
 */
public interface Writer {
    void writeLine(String line);
}
