package com.cefothe.third;

/**
 * Created by cefothe on 12.07.16.
 */
public interface Car {
    String getModel();
    String getDriverName();
    String pushBrake();
    String pushGas();
}
