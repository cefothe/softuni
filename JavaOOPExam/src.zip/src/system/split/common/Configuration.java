package system.split.common;

/**
 * Created by stefanangelov on 7/10/16.
 */
public class Configuration {

    public final static String  HARDWARE="Hardware";
    public final static String  SOFTWARE="Software";
    public final static String  SYSTEM_ANALYSIS="System Analysis";
    public final static String  SYSTEM_SPLIT="System Split";
    public final static String  RELEASE_SOFTWARE="ReleaseSoftwareComponent";

}
