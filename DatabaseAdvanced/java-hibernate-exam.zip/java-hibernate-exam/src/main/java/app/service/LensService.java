package app.service;

import app.domain.dto.json.LensDTO;

/**
 * Created by cefothe on 11.12.16.
 */
public interface LensService {
    void create(LensDTO lensDTO);
}
